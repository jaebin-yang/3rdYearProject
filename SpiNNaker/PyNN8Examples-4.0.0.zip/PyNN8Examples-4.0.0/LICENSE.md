# License Agreement

Up to date information for the whole [SpiNNakerManchester Projects](https://github.com/SpiNNakerManchester) can be found [here](http://spinnakermanchester.github.io/common_pages/4.0.0/LicenseAgreement.html)

As shown there the software is currently being released under the GPL version 3 license listed [here](http://www.gnu.org/copyleft/gpl.html)


# Paper Authorship

See: [here](http://spinnakermanchester.github.io/common_pages/4.0.0/LicenseAgreement.html#paper-authorship)

# Modifications

See: [here](http://spinnakermanchester.github.io/common_pages/4.0.0/LicenseAgreement.html#modifications)

# Contributors

For up to date information on Contributors see the graphs/contributors pages on each project.

For example [https://github.com/SpiNNakerManchester/PyNN8Examples/graphs/contributors](https://github.com/SpiNNakerManchester/PyNN8Examples/graphs/contributors)

[Combined list](http://spinnakermanchester.github.io/common_pages/4.0.0/LicenseAgreement.html#contributors)

