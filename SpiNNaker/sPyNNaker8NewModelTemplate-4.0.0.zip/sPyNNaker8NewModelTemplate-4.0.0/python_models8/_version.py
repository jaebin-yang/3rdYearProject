__version__ = "1!4.0.0"
__version_month__ = "September"
__version_year__ = "2017"
__version_name__ = "Riptalon"
